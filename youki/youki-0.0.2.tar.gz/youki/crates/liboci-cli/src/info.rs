use clap::Parser;

/// Show information about the system
#[derive(Parser, Debug)]
pub struct Info {}
