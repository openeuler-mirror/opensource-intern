use clap::Parser;

/// List created containers
#[derive(Parser, Debug)]
pub struct List {}
