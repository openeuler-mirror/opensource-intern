console.log(Deno.execPath());
