await Deno.emit(new URL("001_hello.js", import.meta.url).href);
