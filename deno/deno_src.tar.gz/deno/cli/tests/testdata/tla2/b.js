export default class Bar {
  constructor(message) {
    this.message = message;
  }
}
