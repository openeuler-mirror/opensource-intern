export default class Foo {
  constructor(message) {
    this.message = message;
  }
}
