import "http://localhost:4545/type_directives_redirect.js";
