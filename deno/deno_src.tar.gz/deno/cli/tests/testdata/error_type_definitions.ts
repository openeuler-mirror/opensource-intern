// @deno-types="./type_definitions/bar.d.ts"
import { Bar } from "./type_definitions/bar.js";

const bar = new Bar();
console.log(bar);
