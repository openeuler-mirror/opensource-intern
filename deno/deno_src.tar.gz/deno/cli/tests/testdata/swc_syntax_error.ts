// deno-fmt-ignore-file
for await (const req of s) {
    let something:
}
