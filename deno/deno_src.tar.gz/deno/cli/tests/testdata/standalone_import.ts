console.log("start");
await import("./001_hello.js");
