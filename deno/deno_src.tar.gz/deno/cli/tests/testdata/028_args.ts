Deno.args.forEach((arg) => {
  console.log(arg);
});
