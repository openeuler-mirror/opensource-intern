export * as c from "./c.ts";

export const b = "b";
