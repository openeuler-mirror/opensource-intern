export function a() {
  console.log("a");
}
