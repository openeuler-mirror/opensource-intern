const a = await import("./subdir/a.ts");

console.log(a);
