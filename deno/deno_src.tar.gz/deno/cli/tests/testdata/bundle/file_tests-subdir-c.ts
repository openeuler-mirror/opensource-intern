export const c = "c";
export default class C {}
