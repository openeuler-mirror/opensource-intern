// @deno-types="https://deno.land/x/lib/mod.d.ts"
import * as lib from "https://deno.land/x/lib/mod.js";

console.log(lib);
