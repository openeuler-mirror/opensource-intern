import * as _i from "./i.ts";
import * as _j from "./j.ts";

const k = globalThis.value ? _i : _j;

export const i = _i;
export const j = _j;

export const {
  a,
} = k;
