export function a(...d: string[]): string {
  return d.join("/");
}
