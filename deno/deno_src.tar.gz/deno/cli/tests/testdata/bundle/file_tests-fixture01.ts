import * as a from "./subdir/a.ts";

console.log(a);
