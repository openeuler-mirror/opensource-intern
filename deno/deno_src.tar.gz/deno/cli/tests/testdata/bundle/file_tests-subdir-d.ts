import { a } from "./a.ts";

export const d = { a };
