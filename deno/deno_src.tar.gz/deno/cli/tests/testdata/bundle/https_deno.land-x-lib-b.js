export const b = [];
