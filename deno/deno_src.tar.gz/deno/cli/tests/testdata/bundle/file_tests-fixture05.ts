import { a } from "./subdir/e.ts";

console.log(a);
