export { a } from "./subdir/k.ts";
