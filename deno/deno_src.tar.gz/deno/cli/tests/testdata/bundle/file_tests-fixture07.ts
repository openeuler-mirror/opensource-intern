import { G } from "./subdir/g.ts";
import { H } from "./subdir/h.ts";

console.log(new G(true), new H(true));
