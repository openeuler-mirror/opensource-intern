// todo(dsherret): delete this and use ./subdir/a.ts in the file once fixtures are restored
export const a = "a";
