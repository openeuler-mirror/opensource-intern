export const c: string[];
