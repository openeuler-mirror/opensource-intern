import { d } from "./subdir/d.ts";

console.log(d);
