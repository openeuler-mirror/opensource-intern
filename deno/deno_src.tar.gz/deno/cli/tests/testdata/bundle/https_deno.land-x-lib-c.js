/// <reference types="./c.d.ts" />

export const c = [];
