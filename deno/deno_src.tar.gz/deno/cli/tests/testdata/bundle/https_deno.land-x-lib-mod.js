export * as a from "./a.ts";
export * as b from "./b.js";
export * as c from "./c.js";

export const mod = [];
