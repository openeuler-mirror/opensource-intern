export enum O {
  A,
  B,
  C,
}
