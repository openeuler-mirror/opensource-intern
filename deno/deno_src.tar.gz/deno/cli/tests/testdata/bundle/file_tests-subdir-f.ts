export const isMain = import.meta.main;
export const modUrl = import.meta.url;
