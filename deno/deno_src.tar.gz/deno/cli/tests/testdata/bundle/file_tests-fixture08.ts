export * as a from "./subdir/a.ts";
