export const a: string[] = [];
