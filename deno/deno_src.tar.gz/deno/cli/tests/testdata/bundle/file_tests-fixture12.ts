import { a } from "./subdir/p.ts";

function b() {
  a();
}

b();
