import config from "./subdir/config.json";
console.log(JSON.stringify(config));
