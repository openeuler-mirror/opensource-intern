console.log(Location);
console.log(Location.prototype);
console.log(location);
