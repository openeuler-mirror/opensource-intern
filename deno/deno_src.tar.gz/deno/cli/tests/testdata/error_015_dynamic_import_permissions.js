(async () => {
  await import("http://localhost:4545/subdir/mod4.js");
})();
