import "./circular1.js";
console.log("circular2");
