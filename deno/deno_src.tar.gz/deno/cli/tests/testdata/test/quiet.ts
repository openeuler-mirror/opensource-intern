Deno.test("console.log", function () {
  console.log("log");
});

Deno.test("console.error", function () {
  console.error("error");
});

Deno.test("console.info", function () {
  console.info("info");
});

Deno.test("console.warn", function () {
  console.info("warn");
});
