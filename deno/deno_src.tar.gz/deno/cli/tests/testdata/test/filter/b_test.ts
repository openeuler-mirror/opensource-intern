Deno.test("foo", function () {});
Deno.test("bar", function () {});
Deno.test("baz", function () {});
