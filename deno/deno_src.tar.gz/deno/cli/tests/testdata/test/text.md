This fixture contains no actual tests.
