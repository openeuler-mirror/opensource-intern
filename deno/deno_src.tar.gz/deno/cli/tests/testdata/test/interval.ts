setInterval(function () {}, 0);
