clearTimeout(setTimeout(() => {}, 1000));

Deno.test("test 1", () => {});
Deno.test("test 2", () => {});
Deno.test("test 3", () => {});
