new Promise((_resolve, reject) => {
  reject(new Error("rejection"));
});
