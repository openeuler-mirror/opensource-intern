Deno.test("test 1", () => {
  throw new Error();
});
Deno.test("test 2", () => {
  throw new Error();
});
Deno.test("test 3", () => {
  throw new Error();
});
Deno.test("test 4", () => {
  throw new Error();
});
Deno.test("test 5", () => {
  throw new Error();
});
Deno.test("test 6", () => {
  throw new Error();
});
Deno.test("test 7", () => {
  throw new Error();
});
Deno.test("test 8", () => {
  throw new Error();
});
Deno.test("test 9", () => {
  throw new Error();
});
Deno.test("test 0", () => {
  throw new Error();
});
