console.log("import.meta.main: %s", import.meta.main);
console.log("import.meta.url: %s", import.meta.url);
