import * as amdLike from "./subdir/amd_like.js";

console.log(amdLike);
