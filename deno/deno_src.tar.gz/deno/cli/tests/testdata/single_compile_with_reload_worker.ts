console.log("Hello from worker");
postMessage(null);
close();
