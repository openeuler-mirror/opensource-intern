import * as c from "./c/mod.ts";

// deno-lint-ignore no-undef
consol.log(c);
