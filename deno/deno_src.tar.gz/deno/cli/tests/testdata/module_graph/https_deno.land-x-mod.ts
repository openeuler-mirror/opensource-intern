import * as a from "./a.ts";

console.log(a);
