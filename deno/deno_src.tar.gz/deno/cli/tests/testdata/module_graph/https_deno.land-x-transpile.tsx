export default class A {
  render() {
    return <div>Hello world!</div>;
  }
}
