/// <reference types="./typesref.d.ts" />

export const a = "a";
