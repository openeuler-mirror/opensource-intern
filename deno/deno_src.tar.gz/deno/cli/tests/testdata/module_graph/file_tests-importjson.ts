import * as config from "./some.json";

console.log(config);
