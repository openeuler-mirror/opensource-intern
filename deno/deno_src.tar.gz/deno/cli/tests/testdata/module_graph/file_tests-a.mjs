import * as b from "./b.ts";

console.log(b);
