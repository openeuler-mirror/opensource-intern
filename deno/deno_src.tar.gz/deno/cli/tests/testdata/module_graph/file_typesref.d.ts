export const a: "a";
