export class ServerRequest {
  respond(value: { body: string }) {
    console.log(value);
  }
}
