import * as $ from "jquery";
import * as _ from "lodash";

console.log($, _);
