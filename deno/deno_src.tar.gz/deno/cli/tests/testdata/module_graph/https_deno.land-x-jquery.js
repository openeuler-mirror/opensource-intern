const $ = {};

export default $;
