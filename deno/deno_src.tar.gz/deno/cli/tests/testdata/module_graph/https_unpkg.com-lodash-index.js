const _ = {};

export default _;
