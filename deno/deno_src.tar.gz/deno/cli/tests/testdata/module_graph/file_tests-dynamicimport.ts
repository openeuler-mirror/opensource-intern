try {
  await import("bare_module_specifier");
} catch (err) {
  console.log(err);
}
