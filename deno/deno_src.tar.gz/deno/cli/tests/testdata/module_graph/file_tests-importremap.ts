import * as a from "https://deno.land/x/a/mod.ts";

console.log(a);
