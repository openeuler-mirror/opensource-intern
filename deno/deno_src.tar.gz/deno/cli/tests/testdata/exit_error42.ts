console.log("before");
Deno.exit(42);
console.log("after");
