import { SomeType } from "./087_hello.ts";

const string: SomeType = "Hi!";
console.log(string);
