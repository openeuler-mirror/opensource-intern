import { printHello } from "https://localhost:5545/subdir/mod2.ts";
printHello();
console.log("success");
