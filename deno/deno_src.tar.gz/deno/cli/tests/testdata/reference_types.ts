/// <reference types="./subdir/types.d.ts" />

console.log(globalThis.a);
