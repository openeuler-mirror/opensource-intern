export interface HelloWorld {
  a: string;
}
