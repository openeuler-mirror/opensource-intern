console.log("main_module2", Deno.mainModule);
