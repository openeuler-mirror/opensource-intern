import { retb } from "./esm_imports_b.js";

if (retb() != "b") throw Error();
