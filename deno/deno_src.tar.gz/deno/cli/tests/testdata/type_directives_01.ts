import * as foo from "http://127.0.0.1:4545/xTypeScriptTypes.js";

console.log(foo.foo);
