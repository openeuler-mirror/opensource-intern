# Hello Markdown

```js
console.log("Hello World");
```

```javascript
console.log("Hello World2");
```

```ts
function hello(name: string) {
  console.log(name);
}

hello("alice");
```

```typescript
function foo(): number {
  return 2;
}
```

```jsonc
{
  // Comment in JSON
  "key": "value",
  "key2": "value2"
}
```

```json
{
  "numbers": ["1", "2"]
}
```
