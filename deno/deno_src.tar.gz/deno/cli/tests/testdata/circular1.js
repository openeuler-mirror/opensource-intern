import "./circular2.js";
console.log("circular1");
