/** Some JSDoc */
export function foo() {
}
