import { isMod4 } from "./subdir/mod6.js";

console.log(isMod4);
