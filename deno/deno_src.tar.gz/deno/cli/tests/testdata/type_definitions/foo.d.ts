/** An exported value. */
export const foo: string;
