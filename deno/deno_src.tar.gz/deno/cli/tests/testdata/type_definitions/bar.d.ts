/// <reference types="baz" />

declare namespace bar {
  export class Bar {
    baz: string;
  }
}
