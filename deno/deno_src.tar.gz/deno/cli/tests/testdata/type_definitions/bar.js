export class Bar {
  constructor() {
    this.baz = "baz";
  }
}
