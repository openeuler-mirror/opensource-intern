export const qat = "qat";
