globalThis.fizz = "fizz";
