/** A global value. */
declare const fizz: string;
