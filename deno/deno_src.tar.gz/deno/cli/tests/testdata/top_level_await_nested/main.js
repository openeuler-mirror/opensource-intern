console.log(1);
await import("./a.js");
console.log(5);
