console.log(2);
await import("./b.js");
console.log(4);
