import "file:///some/dir/file.ts";
