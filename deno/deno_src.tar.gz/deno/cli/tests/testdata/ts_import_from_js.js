import { printHello } from "./ts_import_from_js.deps.js";
printHello();
console.log("success");
