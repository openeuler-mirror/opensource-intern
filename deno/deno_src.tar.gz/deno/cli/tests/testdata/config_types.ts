console.log(globalThis.a);
