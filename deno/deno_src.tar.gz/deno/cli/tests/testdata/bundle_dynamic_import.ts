const mod1 = await import("http://localhost:4545/subdir/mod1.ts");

mod1.printHello3();
