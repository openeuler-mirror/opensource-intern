const c = await import(
  "data:text/javascript;base64,ZXhwb3J0IGRlZmF1bHQgJ0hlbGxvIERlbm8hJw=="
);
console.log(c.default); // Output: "Hello Deno!"
