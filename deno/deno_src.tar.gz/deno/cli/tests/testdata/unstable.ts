console.log(Deno.loadavg);
