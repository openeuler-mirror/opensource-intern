/** @jsxImportSource jsx */

function A() {
  return "hello";
}

export function B() {
  return <A></A>;
}
