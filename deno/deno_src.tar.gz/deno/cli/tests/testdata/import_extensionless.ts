import { printHello3 } from "http://localhost:4545/v1/extensionless";

printHello3();
