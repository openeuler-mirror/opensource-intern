// export { printHello } from "http://localhost:4545/subdir/mod2.ts";
import { printHello } from "data:application/typescript;base64,ZXhwb3J0IHsgcHJpbnRIZWxsbyB9IGZyb20gImh0dHA6Ly9sb2NhbGhvc3Q6NDU0NS9zdWJkaXIvbW9kMi50cyI7";

printHello();
