console.log(delete globalThis.window);
