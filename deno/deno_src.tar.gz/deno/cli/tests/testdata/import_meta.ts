console.log("import_meta", import.meta.url, import.meta.main);

import "./import_meta2.ts";
