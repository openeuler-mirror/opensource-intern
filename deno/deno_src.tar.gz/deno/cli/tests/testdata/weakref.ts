console.log(WeakRef, FinalizationRegistry);
