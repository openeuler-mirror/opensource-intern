import { a } from "./a.js";
import { c } from "./node_modules/b.js";

console.log("hello");
