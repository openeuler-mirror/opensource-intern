function bar(): number {
  return 42;
}

bar();
