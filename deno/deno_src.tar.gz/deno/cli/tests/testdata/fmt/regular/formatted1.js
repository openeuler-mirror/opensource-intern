function foo() {
  return 42;
}

foo();
