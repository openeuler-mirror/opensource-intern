import "http://localhost:4545/subdir/file_with_:_in_name.ts";
