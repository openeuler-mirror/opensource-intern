import { A } from "./recursive_imports/A.ts";

export function test() {
  A();
}
