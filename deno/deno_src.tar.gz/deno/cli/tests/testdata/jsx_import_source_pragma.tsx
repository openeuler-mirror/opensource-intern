/** @jsxImportSource http://localhost:4545/jsx */

function A() {
  return "hello";
}

export function B() {
  return <A></A>;
}
