// deno-lint-ignore-file
require("invalid module specifier");
