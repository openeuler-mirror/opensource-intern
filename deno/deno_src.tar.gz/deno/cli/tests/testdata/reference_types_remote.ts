/// <reference types="http://localhost:4545/subdir/types.d.ts" />

console.log(globalThis.a);
